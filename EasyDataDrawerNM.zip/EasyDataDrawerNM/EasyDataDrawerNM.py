import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import datetime


#------------------请使用‘’Demo.py‘’文件



#版本信息
VERSION = "v1.0.0"

#初始设定
font = {'family':'SimHei',
        'weight':'bold',
        'size':'6'}
plt.rc('font',**font)
time=""



class DataDrawer:
    def __init__(self):
        print('\033[1;32m>>>>>>>>>>>>>>>>>>>>> 欢迎 >>>>>>>>>>>>>>>>>>>>>\033[m')
        print('\033[1;36m欢迎使用数据分析器！版本{}\033[m'.format(VERSION))
        print('\033[1;36mThanks for using Data Analyzer {}！\033[m'.format(VERSION))
        print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 欢迎 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')
        self.tarrgetData = pd.DataFrame()

    #读取数据
    def ReadDataByPath(self,path):
        try:
            self.tarrgetData = pd.read_csv(path)
        except:
            try:
                self.tarrgetData = pd.read_excel(path)
            except:
                print('\033[1;32m>>>>>>>>>>>>>>>>>>>>> 读取数据 >>>>>>>>>>>>>>>>>>>>>\033[m')
                print('\033[1;31m读取数据失败！！\n请尝试以下解决方案：\n1.检查文件路径是否正确。 2.检查文件是否为.csv文件或excel文件。 3.检查文件编码格式是否为UTF-8\033[m'.format(VERSION))
                print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 读取数据 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')
                return
        print('\033[1;32m>>>>>>>>>>>>>>>>>>>>> 读取数据 >>>>>>>>>>>>>>>>>>>>>\033[m')
        print('\033[1;36m成功读取数据！\033[m'.format(VERSION))
        print('\033[1;35m')
        print(self.tarrgetData)
        print('\033[m')
        print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 读取数据 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')


    #绘图器
    def DrawChart(self,arg='all',x=0,type='z'):
        print('\033[1;32m>>>>>>>>>>>>>>>>>>>>> 画图 >>>>>>>>>>>>>>>>>>>>>\033[m')
        #空数据错误
        if self.tarrgetData.shape[0]==0 and self.tarrgetData.shape[1]==0:
            print('\033[1;31m数据为空！！\n请尝试以下解决方案：\n1.使用”ReadDataByPath“函数 从本地文件读取数据。 \033[m')
            print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 画图 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')
            return
        #参数x错误
        if x<0 or x> self.tarrgetData.shape[1]-1:
            print('\033[1;31m参数"x"错误！！\n提示：\n1."x"代表您想要用来当作X轴的数据对应的索引。\n2."x"的取值范围为[0 , 数据的列数-1]之间的整数，例如：假设一共有15列数据，那么您选择的x只能是[0,14]之间的整数。\n3."x"的取值是从0开始的，这就意味着你要给你想用来当X轴的列数-1，例如：你想让第5列的数据当X轴，那么选择你的x应该是4 \033[m')
            print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 画图 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')
            return

        print('\033[1;36m开始绘图！\033[m')
        if arg =='all':
            plt.figure(figsize=(10,10))
            if int(self.tarrgetData.shape[1])<=5:
                n = 0
                for i in range(self.tarrgetData.shape[1]-1):
                    if i != x:
                        n += 1
                        plt.subplot(2, 2, i + 1)
                        # 预处理
                        if not np.issubdtype(self.tarrgetData.dtypes[x], np.number):
                            plt.xticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0] / 6)))
                        if not np.issubdtype(self.tarrgetData.dtypes[i], np.number):
                            plt.yticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0] / 6)))
                        # 绘图
                        plt.title(self.tarrgetData.columns.values[0]+"--"+self.tarrgetData.columns.values[i]+" Chart")

                        if type == 's':
                            try:
                                plt.scatter(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i], s=[5])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
                        elif type == 'z':
                            try:
                                plt.plot(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
            elif int(self.tarrgetData.shape[1])<=10:
                n = 0
                for i in range(self.tarrgetData.shape[1]):
                    if i != x:
                        n += 1
                        plt.subplot(3, 3, n)
                        # 预处理
                        if not np.issubdtype(self.tarrgetData.dtypes[x], np.number):
                            plt.xticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0] / 6)))
                        if not np.issubdtype(self.tarrgetData.dtypes[i], np.number):
                            plt.yticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0] / 6)))
                        # 绘图
                        plt.title(self.tarrgetData.columns.values[0]+"--"+self.tarrgetData.columns.values[i]+" Chart")
                        if type == 's':
                            try:
                                plt.scatter(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i], s=[5])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
                        elif type == 'z':
                            try:
                                plt.plot(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
            elif int(self.tarrgetData.shape[1])<=17:
                n=0
                for i in range(self.tarrgetData.shape[1]):
                    if i !=x:
                        n+=1
                        plt.subplot(4, 4, n)
                        # 预处理
                        if not np.issubdtype(self.tarrgetData.dtypes[x],np.number):
                            plt.xticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        if not np.issubdtype(self.tarrgetData.dtypes[i],np.number):
                            plt.yticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        # 绘图
                        plt.title(self.tarrgetData.columns.values[x]+"--"+self.tarrgetData.columns.values[i]+" Chart")
                        if type == 's':
                            try:
                                plt.scatter(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i], s=[5])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
                        elif type == 'z':
                            try:
                                plt.plot(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
            elif int(self.tarrgetData.shape[1])<=26:
                n=0
                for i in range(self.tarrgetData.shape[1]):
                    if i !=x:
                        n+=1
                        plt.subplot(5, 5, n)
                        # 预处理
                        if not np.issubdtype(self.tarrgetData.dtypes[x],np.number):
                            plt.xticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        if not np.issubdtype(self.tarrgetData.dtypes[i],np.number):
                            plt.yticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        # 绘图
                        plt.title(self.tarrgetData.columns.values[x]+"--"+self.tarrgetData.columns.values[i]+" Chart")
                        if type == 's':
                            try:
                                plt.scatter(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i], s=[5])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
                        elif type == 'z':
                            try:
                                plt.plot(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
            elif int(self.tarrgetData.shape[1])<=37:
                n=0
                for i in range(self.tarrgetData.shape[1]):
                    if i !=x:
                        n+=1
                        plt.subplot(6, 6, n)
                        # 预处理
                        if not np.issubdtype(self.tarrgetData.dtypes[x],np.number):
                            plt.xticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        if not np.issubdtype(self.tarrgetData.dtypes[i],np.number):
                            plt.yticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        # 绘图
                        plt.title(self.tarrgetData.columns.values[x]+"--"+self.tarrgetData.columns.values[i]+" Chart")
                        if type == 's':
                            try:
                                plt.scatter(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i], s=[5])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
                        elif type == 'z':
                            try:
                                plt.plot(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
            elif int(self.tarrgetData.shape[1])<=50:
                n=0
                for i in range(self.tarrgetData.shape[1]):
                    if i !=x:
                        n+=1
                        plt.subplot(7, 7, n)
                        # 预处理
                        if not np.issubdtype(self.tarrgetData.dtypes[x],np.number):
                            plt.xticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        if not np.issubdtype(self.tarrgetData.dtypes[i],np.number):
                            plt.yticks(np.arange(0, self.tarrgetData.shape[0], step=int(self.tarrgetData.shape[0]/6) ))
                        # 绘图
                        plt.title(self.tarrgetData.columns.values[x]+"--"+self.tarrgetData.columns.values[i]+" Chart")
                        if type == 's':
                            try:
                                plt.scatter(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i], s=[5])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
                        elif type == 'z':
                            try:
                                plt.plot(self.tarrgetData.iloc[:, x], self.tarrgetData.iloc[:, i])
                            except:
                                plt.title('错误！！', c='red')
                                print('\033[1;31m处理第 {} 条数据时发生错误！!\033[m'.format(i))
            time = str(datetime.datetime.now().year) + str(datetime.datetime.now().month) + str(
                datetime.datetime.now().day) + str(datetime.datetime.now().hour) + str(
                datetime.datetime.now().minute) + str(datetime.datetime.now().second)

            plt.savefig(fname=time+"保存的图像.png",figsize=[10,10])
            plt.show()
        print('\033[1;36m绘图完毕！\033[m')
        print('\033[1;36m图像已保存为： {}！\033[m'.format(time+"保存的图像.png"))
        print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 画图 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')



    def Analysis(self):
        pass



def 使用教程__遇到问题__请调用此函数():
    print('\033[1;32m>>>>>>>>>>>>>>>>>>>>> 欢迎 >>>>>>>>>>>>>>>>>>>>>\033[m')
    print('\033[1;36m欢迎使用数据分析器！版本{}\033[m'.format(VERSION))
    print('\033[1;36mThanks for using Data Analyzer {}！\033[m'.format(VERSION))
    print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 欢迎 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')

    print('\033[1;32m>>>>>>>>>>>>>>>>>>>>> 介绍 >>>>>>>>>>>>>>>>>>>>>\033[m')
    print('\033[1;36m数据分析器{} 是一款使用非常简单的快速数据处理绘图程序\033[m'.format(VERSION))
    print('\033[1;36m它的当前版本包含以下功能：\033[m')
    print('\033[1;36m\t1.读取数据并画图\033[m')
    print('\033[1;36m\t\t(1)无需数据预处理\033[m')
    print('\033[1;36m\t\t(2)快速出图\033[m')
    print('\033[1;36m\t\t(3)兼容性高\033[m')
    print('\033[1;36m\t\t(4)支持最高处理50个变量，绘制49张图\033[m')
    print('\033[1;36m\t2.超人性化提示内容\033[m')
    print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 介绍 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')

    print('\033[1;32m>>>>>>>>>>>>>>>>>>>>> 教程 >>>>>>>>>>>>>>>>>>>>>\033[m')
    print('\033[1;36m第一步：准备好需要处理的文件，文件后缀名为：".csv"、".xlsx"、".xls"的excel文件\033[m')
    print('\033[1;36m第二步：将要处理的文件放在和本文件同级目录下\033[m')
    print('\033[1;36m第三步：将文件名（带扩展名）加上英文引号，填入”a=EasyDataDrawerNM.Draw()“的括号中（如果你想改变X轴使用的的数据（默认是excel表第一列的数据），那么你可以添加第二个参数“x”,“x”代表您想要用来当作X轴的数据对应的索引，该索引从0开始）（添加参数‘type’可以改变图像的类型（默认为折线图），’s‘对应散点图，’z‘对应折线图）\033[m')
    print('\033[1;36m第四步：运行程序\033[m')
    print('\033[1;36m绘图完成！\033[m')
    print('\033[1;32m<<<<<<<<<<<<<<<<<<<<< 教程 <<<<<<<<<<<<<<<<<<<<<\033[m\n\n')



def Draw(path,x=0,type='z'):
    a = DataDrawer()
    a.ReadDataByPath(path)
    a.DrawChart(x=x,type=type)
